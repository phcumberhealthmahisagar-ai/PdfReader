package com.example.pdfreader

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private var incoming by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) incoming = intent.pdfUri()
        setContent {
            MaterialTheme(if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                ReaderApp(incoming)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.pdfUri()?.let { incoming = it }
    }

    private fun Intent.pdfUri(): Uri? = if (action == Intent.ACTION_VIEW) data else null
}

/** Wraps Android's built-in PdfRenderer. It isn't thread-safe, so all access is serialized. */
class PdfDoc private constructor(private val pfd: ParcelFileDescriptor) : AutoCloseable {
    private val renderer = try { PdfRenderer(pfd) } catch (e: Exception) { pfd.close(); throw e }
    private var closed = false
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    val pageCount = renderer.pageCount
    val aspect = renderer.openPage(0).use { it.width.toFloat() / it.height }

    suspend fun render(index: Int, width: Int): Bitmap? = withContext(Dispatchers.IO) {
        val key = "$index:$width"
        cache.get(key) ?: try {
            synchronized(this@PdfDoc) {
                if (closed) null else {
                    ensureActive() // skip pages the user already scrolled past
                    renderer.openPage(index).use { p ->
                        val h = (width.toFloat() * p.height / p.width).roundToInt()
                        Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888).also {
                            it.eraseColor(android.graphics.Color.WHITE)
                            p.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            cache.put(key, it)
                        }
                    }
                }
            }
        } catch (e: OutOfMemoryError) {
            cache.evictAll(); null
        }
    }

    override fun close() {
        synchronized(this) {
            if (closed) return
            closed = true
            renderer.close(); pfd.close(); cache.evictAll()
        }
    }

    companion object {
        fun open(ctx: Context, uri: Uri): PdfDoc = try {
            PdfDoc(ctx.contentResolver.openFileDescriptor(uri, "r")!!)
        } catch (e: Exception) {
            // Some providers can't seek; copy to cache and open that instead.
            val f = File(ctx.cacheDir, "current.pdf")
            ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
            PdfDoc(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderApp(incoming: Uri?) {
    val ctx = LocalContext.current
    var uri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var night by rememberSaveable { mutableStateOf(false) }
    var doc by remember { mutableStateOf<PdfDoc?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { u -> uri = u } }
    val openPicker = { picker.launch(arrayOf("application/pdf")) }

    LaunchedEffect(incoming) { if (incoming != null) uri = incoming }
    LaunchedEffect(uri) {
        doc?.close(); doc = null; error = null
        val u = uri ?: return@LaunchedEffect
        try {
            doc = withContext(Dispatchers.IO) { PdfDoc.open(ctx, u) }
        } catch (e: Exception) {
            error = "Couldn't open this file. It may be password-protected or damaged. Try another PDF."
        }
    }
    DisposableEffect(Unit) { onDispose { doc?.close() } }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("PDF Reader") },
            actions = {
                TextButton(onClick = { night = !night }) { Text(if (night) "Day" else "Night") }
                TextButton(onClick = { openPicker() }) { Text("Open") }
            }
        )
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
            val d = doc
            val e = error
            when {
                d != null -> Reader(d, "pos:$uri", night)
                e != null -> Text(e, Modifier.padding(24.dp))
                uri != null -> CircularProgressIndicator()
                else -> Button(onClick = { openPicker() }) { Text("Open a PDF") }
            }
        }
    }
}

private val INVERT = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

@Composable
fun Reader(doc: PdfDoc, docKey: String, night: Boolean) {
    val prefs = LocalContext.current.getSharedPreferences("pdf", Context.MODE_PRIVATE)
    val list = rememberLazyListState(prefs.getInt(docKey, 0).coerceIn(0, doc.pageCount - 1))
    var zoom by remember { mutableFloatStateOf(1f) }
    val density = LocalDensity.current

    // Remember the page you were on, per file.
    LaunchedEffect(list) {
        snapshotFlow { list.firstVisibleItemIndex }.collect { prefs.edit().putInt(docKey, it).apply() }
    }

    BoxWithConstraints(
        Modifier.fillMaxSize()
            .background(if (night) Color(0xFF121212) else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        // Pages are re-rendered sharper in half-steps of zoom, capped to keep memory in check.
        val renderPx = with(density) { (maxWidth * ((zoom * 2).roundToInt() / 2f)).roundToPx() }.coerceAtMost(2400)

        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 2f }) }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            if (ev.changes.count { it.pressed } > 1) { // two fingers = pinch; one finger scrolls
                                val z = ev.calculateZoom()
                                if (z != 1f) {
                                    zoom = (zoom * z).coerceIn(1f, 3f)
                                    ev.changes.forEach { it.consume() }
                                }
                            }
                        } while (ev.changes.any { it.pressed })
                    }
                }
                .horizontalScroll(rememberScrollState())
        ) {
            LazyColumn(
                Modifier.width(maxWidth * zoom).fillMaxHeight(),
                state = list,
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(doc.pageCount) { PageView(doc, it, renderPx, night) }
            }
        }

        Surface(
            Modifier.align(Alignment.BottomCenter).padding(16.dp),
            shape = RoundedCornerShape(50),
            color = Color.Black.copy(alpha = 0.65f)
        ) {
            Text("${list.firstVisibleItemIndex + 1} / ${doc.pageCount}", Modifier.padding(12.dp, 6.dp), Color.White)
        }
    }
}

@Composable
fun PageView(doc: PdfDoc, index: Int, widthPx: Int, night: Boolean) {
    var bmp by remember(doc, index) { mutableStateOf<Bitmap?>(null) }
    // Keep showing the old bitmap until the sharper one is ready.
    LaunchedEffect(doc, index, widthPx) { doc.render(index, widthPx)?.let { bmp = it } }
    val b = bmp
    Box(
        Modifier.fillMaxWidth()
            .aspectRatio(b?.let { it.width / it.height.toFloat() } ?: doc.aspect)
            .background(if (night) Color(0xFF1E1E1E) else Color.White)
    ) {
        if (b != null) {
            Image(
                b.asImageBitmap(), "Page ${index + 1}", Modifier.fillMaxSize(),
                colorFilter = if (night) INVERT else null
            )
        }
    }
}
